package lessons;

public class Test {
	
	public static void main(String[] args) {
		
		byte i = -128;
		i--;
		System.out.println(i);
	}

}
