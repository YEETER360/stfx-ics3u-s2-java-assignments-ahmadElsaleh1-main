package lessons;

public class Debugging {

	public static void main(String[] args) {
		
		int foo = 13;
		int bar = 14;
		
		for(int i = 0; i < 3; i++) System.out.println(i);

		
		int sum = foo + bar;

	}

}
