package lessons;

public class Arrays {

	public static void main(String[] args) {

		int[] myInts = {7, 9, 11, 12, 33};
		for(int i = 0; i < myInts.length; i++) 
		{
			System.out.println(myInts[i]);
		}
		
		String[] myStrings = {"dog", "cat", "mouse", "chicken", "hippopotamus"};
		for(int i = 0; i < myStrings.length; i++) 
		{
			System.out.println(myStrings[i]);
		}
	}

}
