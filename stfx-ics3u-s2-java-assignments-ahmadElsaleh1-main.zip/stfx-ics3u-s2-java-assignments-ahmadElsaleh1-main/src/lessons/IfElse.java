package lessons;

public class IfElse {

	public static void main(String[] args) {
		
		//Code block will always execute
		if(true) {
			System.out.println("Code block is executed");
		}
		
		//Code block will never execute
		if(false) {
			System.out.println("Code block2 never executed");
		}
		
		//Code block will always execute when true
		if(3 > 1) {
			System.out.println("Code block3 is executed");
		}

	}

}
