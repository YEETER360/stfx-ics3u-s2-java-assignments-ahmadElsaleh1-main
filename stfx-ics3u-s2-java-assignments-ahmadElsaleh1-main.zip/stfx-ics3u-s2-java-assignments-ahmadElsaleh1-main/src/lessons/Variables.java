package lessons;

public class Variables {

	public static void main(String[] args) {
		// Variable declarations
		int myGrade = 90;
		double myDouble = 0.0;
		char myCharacter = 's';
		String myString = "Hello World";
		
		boolean myBoolean = true;
		boolean myBoolean2 = false;
		
		/* Constant variables
		 * constant variables do not change
		 * All capital letters
		 */
		
		final double TAX_RATE = 0.13;
		
	}

}
