package sandbox;

public class HelloWorld2 {

	public static void main(String[] args) {
		// This is a comment, but you already knew that didn't you
		/*
		 I am
		 now
		 commenting
		 on multiple
		 lines
		*/
		System.out.println("Hello world, once again");

	}

}
