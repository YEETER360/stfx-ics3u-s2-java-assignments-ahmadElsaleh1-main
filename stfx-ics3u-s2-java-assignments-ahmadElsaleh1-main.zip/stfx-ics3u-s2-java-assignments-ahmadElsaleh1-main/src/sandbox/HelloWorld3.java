package sandbox;

public class HelloWorld3 {

	public static void main(String[] args) {
		System.out.println("Hello world 3");

	}

}
